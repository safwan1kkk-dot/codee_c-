#include <iostream>
using namespace std;

   int main() 
   {
    int number;
    cout << "Enter a num"<<endl;
    cin >> number;

    if (number % 3 == 0 && number % 5 == 0) 
    
        cout << "The num is true by 3 and 5" << endl;
     
    else 
    
        cout << "The num is not folse by 3 and 5" << endl;
    
    
    
    return 0;
}