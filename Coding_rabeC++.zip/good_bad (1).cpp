#include <iostream>
using namespace std;

int main() 
{
  double student ; 
  cout << "Enter your num studen" << endl;
  cin >> student;
   
   if ( student >= 90)
   {
   cout << "nays" ;
   } 
   else if ( student >= 80)
   {
   cout << "bood";
   } 
   else if ( student  >= 50)
   {
   cout << "fild";
   } 
   else
   {
    cout << "rasp";
   } 
    return 0;
}