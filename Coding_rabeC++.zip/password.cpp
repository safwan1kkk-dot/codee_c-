#include <iostream>
using namespace std;

   int main() 
   {
    string password;
    cout << "Enter pass"<<endl;
    cin >> password;

    if (password == "7716") 
    {
        cout << "true pass" << endl;
    } 
    else 
    
        cout << "fouls pass" << endl;
    
    
    return 0;
}