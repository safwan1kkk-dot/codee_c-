#include <iostream>
using namespace std;

int main() 
{
  int num  ; 
  cout << "Enter your num" << endl;
  cin >> num;
  
    if ( num > 0)
    {
    cout << "mwgp" << endl;
    } 
    else if ( num < 0)
    {
    cout << "salp" << endl;
    } 
    return 0;
}