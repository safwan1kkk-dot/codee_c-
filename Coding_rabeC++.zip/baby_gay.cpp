#include <iostream>
using namespace std;

int main() 
{
  int age  ; 
  cout << "Enter your age" << endl;
  cin >> age;
    if (age  <= 18)
    {
    cout << "baby" << endl;
    }
    else if ( age <= 20)
    { 
    cout << "gay" << endl;
    } 
    return 0;
}