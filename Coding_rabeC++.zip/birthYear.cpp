#include <iostream>
using namespace std;

   int main() 
   {
    int old_year;
    int Year_now= 2026;

    cout << "Enter your old year"<<endl;
    cin >> old_year;

    int age = Year_now - old_year;
    cout << "Your age"<<endl << age << endl;
    
    return 0;
}