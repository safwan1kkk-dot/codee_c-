#include <iostream>
using namespace std;

int main() 
{
    int age;
    cout << "Enter your age: ";
    cin >> age;

    if (age >= 20 && age <= 75) 
    {
        cout << "you can wark" << endl;
    } 
    else 
    
        cout << "I cant work" << endl;
    

    
    return 0;
}