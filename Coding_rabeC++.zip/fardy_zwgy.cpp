#include <iostream>
using namespace std;

int main() 
{
  int num  ; 
  cout << "Enter your num" << endl;
  cin >> num;
  
    if ( num / 2 )
    {
    cout << "zwgy" << endl;
    } 
    else if ( num / 1)
    {
    cout << "fardy" << endl;
    } 
    return 0;
}