#include <iostream>
using namespace std;

int main() 
{
    int day_wark;
    int day_end; 
    cout << "Enter a day (1-7)";
    cin >> day_wark;

    if (day_wark == 1 || day_wark == 2  || day_wark == 3  || day_wark == 5) 
    {
        cout << "wark_1" << endl;
    } 
    else  
    
        cout << "end_1" << endl;
    
    return 0;
}