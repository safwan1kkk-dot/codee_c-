#include <iostream>

using namespace std;

int main() {
    double number;

    cout << "Enter a number";
    cin >> number;

    if (number > 0) {
        cout << "The number is +" << endl;
    } 
    else if (number <1) {
        cout << "The number is -" << endl;
    } 
    else 
    {
        cout << "The number 0" << endl;
    }

    return 0;
}
