#include <iostream>
using namespace std;

   int main() 
   {
    int number;
    double num1, num2;
    double nums2, nums1;
    cout << "Enter 2 num"<<endl;
    cin >> num1 >> num2;
    
    if (num1 > num2) 
    {
        cout << "big num"<<endl << num1 << endl;
    } 
    else if (num2 > num1) 
    {
        cout << "big num"<<endl << num2 << endl;
    } 
    else if (num1 < num2)
    {
        cout << "small num" << endl;
    }
    else if (num2 < num1)
    {
    cout << "small num" << endl;
    } 
    else
    
    cout << "equal num" << endl;
    
    return 0;
}